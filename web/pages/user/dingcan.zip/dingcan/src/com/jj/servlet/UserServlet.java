package com.jj.servlet;

import com.jj.bean.User;
import com.jj.service.UserService;
import com.jj.service.impl.UserServiceImlp;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private UserService userService;


    public UserServlet() {
        super();
        userService = new UserServiceImlp();
    }


    /**
     * 注册用户的操作
     *
     * @param request
     * @param response
     * @throws IOException
     * @throws ServletException
     */
    public void regist(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 获取注册的用户名
//		String username = request.getParameter("username");
        // 获取用户注册的密码
//		String password = request.getParameter("password");
        // 获取用户注册的邮箱号
//		String email = request.getParameter("email");
        // 获取用户注册的验证码
        // String code = request.getParameter("code");

        // 把传递过来的参数赋值到javaBean对象中
        User t = new User();
        com.jj.utils.Utils.copyParameter2Bean(request.getParameterMap(), t);


        // 我们假设我们生成的验证码是abcde
        //if ("abcde".equals(code)) {
        // 判断用户名是否已经存在！
        //
    }
}